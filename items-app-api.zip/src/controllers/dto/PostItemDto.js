"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostItemDto = void 0;
class PostItemDto {
}
exports.PostItemDto = PostItemDto;
