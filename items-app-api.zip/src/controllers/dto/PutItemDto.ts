export default class PutItemDto {
    constructor(
        name?: string,
        description?: string,
        itemProductionCost?: number) {}
}