"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class PutItemDto {
    constructor(name, description, itemProductionCost) { }
}
exports.default = PutItemDto;
